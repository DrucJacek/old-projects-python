 -------1-----------------
 for i in range(1,21):
     print(i)
---------2------------
 l=[]
 for i in range(50,101):
     l.append(i)
 print(str(l[::-1]))
 ---------3------------

 ----------4-----------
 y=int(input())
 for i in range(0,y):
     print(i)
 --------5-------------
 x=int(input())
 y=int(input())
 for i in range(x,y)
     print(i)
 --------6------------
 liczba=0
 for i in range(99999999):
     liczba=int(input())
     if liczba>0:
         break
     else:
         liczba=int(input())
 -----------7------------
 x=int(input())
 y=int(input())
 s=0
 for i in range(x,y):
     if i%2==1:
         s+=i
 print(s)
 ----------8--------------
 x=int(input())
 y=int(input())
 for i in range(99999):
     if x>0 and y>0:
         print("Pole prostokata to: ",x*y)
         break
     else:
         print("Podaj dodatnie liczby")
         x = int(input())
         y = int(input())
 -----------9----------------
 x=input()
 print(x[::-1])
 ---------10-----------------
 for i in range(1,101):
     if i%8==0:
         print(i)
